import pandas as pd
import numpy as np


weights = pd.read_csv("data/weights.csv")


def generate_score(bus_name, df):
    business_name = bus_name.lower().strip()
    bus = df[df['name'].str.lower().str.strip() == business_name]
    
    country = bus['country'].values[0] if not bus.empty else "Country not found"
    all_in_country = df[df['country'] == country]
    score = bus['model_output'].values[0] if not bus.empty else "Business not found"
    country_max = all_in_country['model_output'].max() if not all_in_country.empty else 0
    country_shift_score = score/country_max * 100 if country_max > 0 else 0

    #relative industry score
    industry = bus['category'].values[0] if not bus.empty else "Country not found"
    all_in_industry = df[df['category'] == industry]
    score = bus['model_output'].values[0] if not bus.empty else "Business not found"
    industry_max = all_in_industry['model_output'].max() if not all_in_industry.empty else 0
    industry_shift_score = score/industry_max * 100 if industry_max > 0 else 0
    
    # st.success(f"Confidence Score for {original_business_name}: {score}")
    # st.write(f"Relative score in {country}: {country_shift_score:.2f}")

    # st.write("Factors that contributed to the score")
    bus_features = bus.drop(columns=['name', 'model_output', 'country', 'category'])


    contributed = []
    value = []
    
    # sum = 0

    for col in bus_features.columns:
        # print(col)
        contribution = bus_features[col].values[0] * weights[col].values[0]
        contributed.append(col)
        value.append(contribution)
    
    
    # # for i in range(len(value)):
    # #     value[i] = 

    to_show = pd.DataFrame({
        'Feature': contributed,
        'Amount Contributed': value
    })
    sorted_to = to_show.sort_values(by='Amount Contributed', ascending=False)
    

    # chart = alt.Chart(sorted_to).mark_bar().encode(
    #     x=alt.X('contributed', sort='-y'),  # Sort bars by value descending
    #     y='value'
    # )

    # st.altair_chart(chart, use_container_width=True)
    return {"country": country, "industry": industry, "score": score, "country_shift_score": country_shift_score, "industry_shift_score": industry_shift_score, "chart": sorted_to}