import streamlit as st
import pandas as pd
from tools.util import generate_score
import altair as alt

df = pd.read_csv("data/final_data.csv") #use data/final_data.csv for actual implementation
# df = process_data(df)
# df = df.head(1000)
df = df.sort_values(by='name', ascending=True)
intercept = -9.770495363901844

weights = pd.read_csv("data/weights.csv")

st.title("BrightQuery Confidence Scoring System")

st.write("This application utilizes our confidence scoring system to evaluate the legitimacy of a business")
st.write("Enter the business name and select 'Generate Score' to see the confidence score.")

st.write("Do you want to compare two businesses?")
if st.checkbox("Yes"):


    first_bus_name = st.selectbox(
    "First Business Name",
    df['name'].unique(),
    index=None,
    placeholder="Select business name...",
    )
    second_bus_name = st.selectbox(
    "Second Business Name",
    df['name'].unique(),
    index=None,
    placeholder="Select business name...",
    )
    if st.button("Generate Score") and second_bus_name and first_bus_name:
        col1, col2 = st.columns(2)
        first_score = generate_score(first_bus_name, df)
        second_score = generate_score(second_bus_name, df)


        with col1:
            st.success(f"Confidence Score for {first_bus_name}: {first_score['score']}")
            st.write(f"Relative score in {first_score['country']}: {first_score['country_shift_score']:.2f}")
            st.write(f"Relative score in {first_score['industry']}: {first_score['industry_shift_score']:.2f}")

            chart = alt.Chart(first_score['chart']).mark_bar().encode(
            x=alt.X('Feature', sort='-y'),  # Sort bars by value descending
            y='Amount Contributed'
            )

            st.altair_chart(chart, use_container_width=True)

        with col2:
            st.success(f"Confidence Score for {second_bus_name}: {second_score['score']}")
            st.write(f"Relative score in {second_score['country']}: {second_score['country_shift_score']:.2f}")
            st.write(f"Relative score in {second_score['industry']}: {second_score['industry_shift_score']:.2f}")

            chart = alt.Chart(second_score['chart']).mark_bar().encode(
            x=alt.X('Feature', sort='-y'),  # Sort bars by value descending
            y='Amount Contributed'
            )

            st.altair_chart(chart, use_container_width=True)

else:

    # original_business_name = st.text_input("Business Name")
    original_business_name = st.selectbox(
        "Business Name",
        df['name'].unique(),
        index=None,
        placeholder="Select business name...",
        )



    if st.button("Generate Score"):
        business_name = original_business_name.lower().strip()
        bus = df[df['name'].str.lower().str.strip() == business_name]

        # Relative country score
        country = bus['country'].values[0] if not bus.empty else "Country not found"
        all_in_country = df[df['country'] == country]
        score = bus['model_output'].values[0] if not bus.empty else "Business not found"
        country_max = all_in_country['model_output'].max() if not all_in_country.empty else 0
        country_shift_score = score/country_max * 100 if country_max > 0 else 0

        #relative industry score
        industry = bus['category'].values[0] if not bus.empty else "Country not found"
        all_in_industry = df[df['category'] == industry]
        score = bus['model_output'].values[0] if not bus.empty else "Business not found"
        industry_max = all_in_industry['model_output'].max() if not all_in_industry.empty else 0
        industry_shift_score = score/industry_max * 100 if industry_max > 0 else 0
        
        st.success(f"Confidence Score for {original_business_name}: {score}")
        st.write(f"Relative score in {country}: {country_shift_score:.2f}")
        st.write(f"Relative score in {industry}: {industry_shift_score:.2f}")

        st.write("Factors that contributed to the score")
        bus_features = bus.drop(columns=['name', 'model_output', 'country', 'category'])


        contributed = []
        value = []
        
        # sum = 0

        for col in bus_features.columns:
            contribution = bus_features[col].values[0] * weights[col].values[0]
            contributed.append(col)
            value.append(contribution)
        
        
        # for i in range(len(value)):
        #     value[i] = 

        to_show = pd.DataFrame({
            'Feature': contributed,
            'Amount Contributed': value
        })
        sorted_to = to_show.sort_values(by='Amount Contributed', ascending=False)
        

        chart = alt.Chart(sorted_to).mark_bar().encode(
            x=alt.X('Feature', sort='-y'),  # Sort bars by value descending
            y='Amount Contributed'
        )

        st.altair_chart(chart, use_container_width=True)
        # print(sum)